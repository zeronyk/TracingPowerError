﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Dummy")]
[assembly: AssemblyDescription("Dummy")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("S.K.M. Informatik GmbH")]
[assembly: AssemblyProduct("dummy.Properties")]
[assembly: AssemblyCopyright("Copyright © S.K.M. Informatik GmbH 2019")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("4d56f4cd-f923-417b-88b8-55aa867b4f64")]
[assembly: AssemblyVersion("0.3.0.0")]
[assembly: AssemblyFileVersion("0.3.0.0")]