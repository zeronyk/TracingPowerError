﻿using System;

namespace ZfFrameworkTest
{
    class Program
    {
        static void Main(string[] args)
        {
            Vector tempVector = new Vector()
            {
                x = 1,
                y = 2,
                z = 3
            };

            //System.IO.Stream tempStream = new System.IO.MemoryStream();
            ZeroFormatter.ZeroFormatterSerializer.Serialize(tempVector);

            //tempStream.Dispose();
            //tempStream = null;
        }
    }
}