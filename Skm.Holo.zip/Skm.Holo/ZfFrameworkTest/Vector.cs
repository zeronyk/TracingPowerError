﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ZfFrameworkTest
{
	[ZeroFormatter.ZeroFormattable]
	public struct Vector
    {
		[ZeroFormatter.Index(0)]
		public float x;
		[ZeroFormatter.Index(1)]
		public float y;
		[ZeroFormatter.Index(2)]
		public float z;

        public Vector(float x, float y, float z)
        {
			this.x = x;
			this.y = y;
			this.z = z;
		}
	}
}